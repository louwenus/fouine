(* un type pour des expressions arithm�tiques simples *)
type expr =
    Const of int
  | Add of expr*expr
  | Mul of expr*expr






  
